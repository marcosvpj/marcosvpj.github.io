+++
title = "Como ver as alteracoes nao commitadas no git via linha de commando"
date = 2015-04-28
description = "Dicas para utilizacao do git via linha de comando."
tags = ["git"]
categories = ["codigo"]
+++

Apos trocar de sistema operacional do Mac para Linux nao encontrei um substituto decente para o Source Tree.

Entao ao inves de me contentar com um cliente mais ou menos decidi partir para a linha de comando.

Tudo ia bem ate ter de visualizar as alteracoes de um determinado arquivo antes de efetuar um commit.

Bem, apos uma breve busca no google encontrei dois modos de resolver isso via linha de comando.

Git Diff

```shell
$ git diff caminho/para/o/arquivo/desejado
```

Com o git diff so basta passar via parametro o caminho para o arquivo que se deseja visualizar as alteracoes e pronto.

Para mais informacoes a documentacao official pode ser encontrada aqui: [http://git-scm.com/docs/git-diff](http://git-scm.com/docs/git-diff)


Git Status

```shell
$ git status -v
```
