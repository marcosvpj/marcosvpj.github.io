+++
title = "Agora"
description = "O que estou fazendo agora"
+++

Esta pagina e inspirada no movimento [/now](https://nownownow.com/about) criado por Derek Sivers.

## Onde estou

Morando off-grid em uma area rural, trabalhando remotamente com energia solar e Starlink.

## No que estou trabalhando

- Expandindo meu sistema de energia solar (veja os posts sobre [situacao atual](/posts/solar-system-current-state/) e [plano de expansao](/posts/solar-system-expansion/))
- Desenvolvendo em Go e Python
- Mantendo este blog

## O que estou lendo

Confira minha [lista de livros](/livros/).

---

*Ultima atualizacao: Outubro 2025*
