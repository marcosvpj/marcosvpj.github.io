+++
title = "Now"
description = "What I'm doing now"
+++

This page is inspired by the [/now](https://nownownow.com/about) movement created by Derek Sivers.

## Where I am

Living off-grid in a rural area, working remotely with solar power and Starlink.

## What I'm working on

- Expanding my solar power system (see posts about [current state](/en/posts/solar-system-current-state/) and [expansion plan](/en/posts/solar-system-expansion/))
- Developing in Go and Python
- Maintaining this blog

## What I'm reading

Check out my [book list](/en/livros/).

---

*Last updated: October 2025*
