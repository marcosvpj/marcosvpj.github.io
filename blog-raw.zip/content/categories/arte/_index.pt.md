+++
title = "Arte"
description = "Fotografia, viagens, literatura e experiencias culturais"
+++

A arte me conecta com o mundo de formas que o codigo nao consegue. Aqui compartilho minhas experiencias artisticas e culturais - seja atraves de fotografias de viagens, resenhas de livros, ou reflexoes sobre experiencias que marcaram minha vida.

A beleza esta nos detalhes, e documentar esses momentos e uma forma de preservar memorias e compartilhar perspectivas.
