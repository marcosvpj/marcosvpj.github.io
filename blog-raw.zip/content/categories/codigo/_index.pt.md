+++
title = "Codigo"
description = "Programacao, desenvolvimento de software e tecnologia"
+++

Programacao e minha profissao e minha paixao. Aqui compartilho aprendizados tecnicos, dicas de desenvolvimento, e reflexoes sobre a arte de escrever software.

De Go a Python, de arquitetura de sistemas a boas praticas de desenvolvimento - cada post e uma oportunidade de documentar o que aprendi e ajudar outros desenvolvedores em suas jornadas.
