+++
title = "Code"
description = "Programming, software development and technology"
+++

Programming is my profession and my passion. Here I share technical learnings, development tips, and reflections on the art of writing software.

From Go to Python, from systems architecture to development best practices - each post is an opportunity to document what I've learned and help other developers on their journeys.
