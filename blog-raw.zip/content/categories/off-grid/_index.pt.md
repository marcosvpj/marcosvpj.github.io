+++
title = "Off-grid"
description = "Projetos e experiencias de vida fora da rede eletrica convencional"
+++

Viver off-grid e uma jornada de aprendizado constante. Nesta secao, documento minha experiencia construindo e mantendo um sistema de energia solar, os desafios de viver em area rural, e a busca por maior autonomia e sustentabilidade.

Desde paineis solares ate baterias de litio, desde controladores de carga ate geradores de backup - cada componente e uma peca de um quebra-cabeca maior que representa minha busca por independencia energetica.
