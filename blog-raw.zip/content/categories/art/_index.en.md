+++
title = "Art"
description = "Photography, travel, literature and cultural experiences"
+++

Art connects me with the world in ways that code cannot. Here I share my artistic and cultural experiences - whether through travel photography, book reviews, or reflections on experiences that have marked my life.

Beauty is in the details, and documenting these moments is a way to preserve memories and share perspectives.
