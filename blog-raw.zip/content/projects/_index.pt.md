+++
title = "Projetos"
description = "Minha forma de pensar e projetos em diferentes areas"
layout = "projects-landing"
+++

## Minha Filosofia

<!-- TODO: Edite este texto com sua filosofia pessoal -->

Acredito que a vida e feita de experimentos. Cada projeto e uma oportunidade de aprender, errar e evoluir. Nao busco perfeicao - busco progresso.

Meus projetos se dividem em tres grandes areas que refletem quem eu sou:

---

## Areas de Projeto

<div class="project-categories">

### [Off-grid](/categories/off-grid/)

Viver fora da rede eletrica convencional e mais do que uma escolha pratica - e uma filosofia de vida. Aqui documento minha jornada construindo um sistema de energia solar, enfrentando os desafios de viver em area rural, e buscando maior autonomia e sustentabilidade.

**Temas:** Energia solar, baterias, sistemas autonomos, vida rural

---

### [Arte](/categories/arte/)

A arte me conecta com o mundo de formas que o codigo nao consegue. Fotografia, viagens, literatura - sao formas de ver e registrar a vida. Aqui compartilho minhas experiencias artisticas e culturais.

**Temas:** Fotografia, viagens, livros, cultura

---

### [Codigo](/categories/codigo/)

Programacao e minha profissao e minha paixao. Aqui compartilho aprendizados tecnicos, dicas de desenvolvimento, e reflexoes sobre a arte de escrever software.

**Temas:** Go, Python, arquitetura de software, boas praticas

</div>
