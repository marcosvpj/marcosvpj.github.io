+++
title = "Projects"
description = "My way of thinking and projects across different areas"
layout = "projects-landing"
+++

## My Philosophy

<!-- TODO: Edit this text with your personal philosophy -->

I believe life is made of experiments. Every project is an opportunity to learn, fail, and grow. I don't seek perfection - I seek progress.

My projects are divided into three main areas that reflect who I am:

---

## Project Areas

<div class="project-categories">

### [Off-grid](/en/categories/off-grid/)

Living off the conventional power grid is more than a practical choice - it's a philosophy of life. Here I document my journey building a solar power system, facing the challenges of rural living, and seeking greater autonomy and sustainability.

**Topics:** Solar energy, batteries, autonomous systems, rural living

---

### [Art](/en/categories/art/)

Art connects me with the world in ways that code cannot. Photography, travel, literature - they are ways of seeing and recording life. Here I share my artistic and cultural experiences.

**Topics:** Photography, travel, books, culture

---

### [Code](/en/categories/code/)

Programming is my profession and my passion. Here I share technical learnings, development tips, and reflections on the art of writing software.

**Topics:** Go, Python, software architecture, best practices

</div>
