+++
title = "Books"
description = "Books I've read"
+++

Throughout our lives we learn a lot from our experiences and from our mistakes.
The problem is that it takes time. But there's a shortcut. *Books*.

By reading we can learn from the experiences of others who have already walked the path we are now following.

Recent books I've read:

<div class="row">
<div class="col s3 photo" style="padding:1em">
  <img src="/img/livros/budismo-na-mesa-do-bar-lodro-rinzler.jpg" alt="Buddhism on the Bar Stool - Lodro Rinzler" title="Buddhism on the Bar Stool - Lodro Rinzler" style="padding:5px" />
  <strong>Buddhism on the Bar Stool<br><small>Lodro Rinzler</small></strong>
  <small> - <a href="http://amzn.to/2zdBUJj" target="_blank">Buy</a></small>
</div>

<div class="col s3 photo" style="padding:1em">
  <img src="/img/livros/aniquilacao-jeff-vandermeer.jpg" alt="Annihilation (Southern Reach Book 1) - Jeff VanderMeer" title="Annihilation (Southern Reach Book 1) - Jeff VanderMeer" style="padding:5px" />
  <strong>Annihilation<br><small>Jeff VanderMeer</small></strong>
  <small> - <a href="http://amzn.to/2xZXrE3" target="_blank">Buy</a></small>
</div>

<div class="col s3 photo" style="padding:1em">
  <img src="/img/livros/the-checklist-manifesto-atul-gawande.jpg" alt="The Checklist Manifesto - Atul Gawande" title="The Checklist Manifesto - Atul Gawande" style="padding:5px" />
  <strong>The Checklist Manifesto<br><small>Atul Gawande</small></strong>
  <small> - <a href="http://amzn.to/2y2McL3" target="_blank">Buy</a></small>
</div>

<div class="col s3 photo" style="padding:1em">
  <img src="/img/livros/essencialismo-greg-mckeown.jpg" alt="Essentialism - Greg McKeown" title="Essentialism - Greg McKeown" style="padding:5px" />
  <strong>Essentialism<br><small>Greg McKeown</small></strong>
  <small> - <a href="http://amzn.to/2h2PXct" target="_blank">Buy</a></small>
</div>

<div class="col s3 photo" style="padding:1em">
  <img src="/img/livros/girlboss-sophia-amoruso.jpg" alt="#GIRLBOSS - Sophia Amoruso" title="#GIRLBOSS - Sophia Amoruso" style="padding:5px" />
  <strong>#GIRLBOSS<br><small>Sophia Amoruso</small></strong>
  <small> - <a href="http://amzn.to/2AintUm" target="_blank">Buy</a></small>
</div>
</div>
